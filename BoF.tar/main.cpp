/**
 * Includes
 */
#include <iomanip>
#include <iostream>
#include <stdio.h>
using namespace std;

/**
 * Function prototypes
 */

/**
 * Main
 */
int main() {

    //local constants

    //local variables
    
    /******************* main program *******************/

    cout << "BoF";

    //exit
    return 0;

}//end main
